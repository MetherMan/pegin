@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "work\laqia-runtime\python\python.exe" (
 echo [오류] outputs와 work 두 폴더가 함께 보이는 곳에 넣어 주세요.
 echo outputs 안이나 work 안에 넣으면 안 됩니다. 적용방법.txt를 확인해 주세요.
 pause
 exit /b 1
)
"work\laqia-runtime\python\python.exe" -X utf8 "update\father_update.py" --root "%~dp0."
if errorlevel 1 (
 echo 업데이트가 완료되지 않았습니다. 위 오류를 확인해 주세요.
 pause
 exit /b 1
)
pause
